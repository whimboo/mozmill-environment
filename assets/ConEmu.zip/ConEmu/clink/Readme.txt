﻿You may try «Clink» - bash style autocomplete
Download and unpack files to this folder

http://clink.googlecode.com

Note! Clink distribution has subfolders.
Files clink_dll_x86.dll and clink_dll_x64.dll
must be located in THIS folder exactly.
